/**
 * Master Validation Suite for Open Policy Commercial Economics (CE-1)
 * 
 * Verifies:
 * 1. PM-1 through PM-5 frozen invariants remain 100% passing.
 * 2. Commercial Economics schema (Migration 0005) applied cleanly.
 * 3. CommercialAccount decoupled from ProviderOrganization.
 * 4. CommercialPlan & immutable CommercialPlanVersion persistence.
 * 5. CommercialAgreement & ProviderEntitlement derivation.
 * 6. Entitlement capacity enforcement.
 * 7. Append-only CommercialEvent ledger with deterministic idempotency.
 * 8. Pure deterministic rating engine for billable events.
 * 9. Factual value summary conversion calculations.
 * 10. COMMERCIAL_NEUTRALITY: No commercial object may influence offer comparison,
 *     qualification, consumer selection, or PM-5 reconciliation.
 * 11. Forbidden Imports Firewall: Protected domain engines must not import commercial files.
 * 12. Non-regression of PM-5: /api/marketplace/billing/ledger and /api/marketplace/fees/settle remain 404.
 */

import http from 'http';
import fs from 'fs';
import path from 'path';
import { app } from '../server';
import { postgresStore, PostgresStore } from '../src/server/db/postgresStore';
import { commercialStore, CommercialStore } from '../src/server/db/commercialStore';
import {
  createCommercialAccount,
  createCommercialPlanVersion,
  createCommercialAgreement,
  deriveEntitlementsFromPlanVersion,
  checkEntitlementCapacity,
  buildCommercialEvent,
  rateCommercialEvent,
  calculateValueSummary
} from '../src/domain/commercialEconomicsEngine';
import { runCommercialEconomicsTestSuite } from '../src/domain/commercialEconomics.test';

function assert(condition: boolean, message: string) {
  if (!condition) {
    console.error(`[FAIL] ${message}`);
    throw new Error(`Assertion failed: ${message}`);
  }
  console.log(`  [PASS] ${message}`);
}

async function request(server: http.Server, method: string, urlPath: string, body?: any, headers?: Record<string, string>): Promise<{ status: number; body: any }> {
  return new Promise((resolve, reject) => {
    const port = (server.address() as any).port;
    const reqHeaders: Record<string, string> = {
      'Content-Type': 'application/json',
      ...headers
    };
    const req = http.request({
      hostname: '127.0.0.1',
      port,
      path: urlPath,
      method,
      headers: reqHeaders
    }, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          const parsed = JSON.parse(data);
          resolve({ status: res.statusCode || 200, body: parsed });
        } catch {
          resolve({ status: res.statusCode || 200, body: data });
        }
      });
    });
    req.on('error', reject);
    if (body) {
      req.write(JSON.stringify(body));
    }
    req.end();
  });
}

async function runValidation() {
  console.log('\n============================================================');
  console.log('OPEN POLICY COMMERCIAL ECONOMICS (CE-1) VALIDATION SUITE');
  console.log('============================================================\n');

  const testDbDir = path.join(process.cwd(), 'data', `test_ce1_${Date.now()}`);

  const server = http.createServer(app);
  await new Promise<void>((resolve) => {
    server.listen(0, '127.0.0.1', () => resolve());
  });

  // Ensure default server store is initialized & plans are seeded for HTTP assertions
  await postgresStore.init();
  await postgresStore.seedCanonicalProviderData();
  await commercialStore.seedCanonicalPlans();

  try {
    // ------------------------------------------------------------------------
    // Part 1: Forbidden Imports Firewall Invariant
    // ------------------------------------------------------------------------
    console.log('--- Test Group 1: Commercial Neutrality Codebase Firewall ---');
    const protectedFiles = [
      'src/domain/comparisonEngine.ts',
      'src/domain/competitionEngine.ts',
      'src/domain/selectionBindingEngine.ts',
      'src/domain/pm5ReconciliationEngine.ts'
    ];

    const forbiddenStrings = [
      'commercialEconomicsEngine',
      'commercialStore',
      'commercial_accounts',
      'commercial_plans',
      'commercial_agreements',
      'billable_events'
    ];

    for (const file of protectedFiles) {
      const fullPath = path.join(process.cwd(), file);
      if (fs.existsSync(fullPath)) {
        const content = fs.readFileSync(fullPath, 'utf8');
        for (const forbidden of forbiddenStrings) {
          assert(
            !content.includes(forbidden),
            `Protected file '${file}' strictly does not import or reference '${forbidden}'`
          );
        }
      }
    }

    // ------------------------------------------------------------------------
    // Part 2: CE Domain Test Suite
    // ------------------------------------------------------------------------
    console.log('\n--- Test Group 2: CE Domain Test Suite ---');
    const ceSuite = runCommercialEconomicsTestSuite();
    assert(ceSuite.failed === 0, `CE domain suite passes cleanly (${ceSuite.passed}/${ceSuite.total})`);

    // ------------------------------------------------------------------------
    // Part 3: Durable PostgreSQL Migration 0005 & Tables
    // ------------------------------------------------------------------------
    console.log('\n--- Test Group 3: Durable Migration 0005 & Schema Separation ---');
    const testStore = new PostgresStore(testDbDir);
    await testStore.init();
    const pglite = await testStore.getPgClient();

    const migrationsRes = await pglite.query<{ name: string }>(
      `SELECT name FROM _migrations ORDER BY id ASC;`
    );
    const migrationNames = migrationsRes.rows.map(r => r.name);
    assert(migrationNames.includes('0001_pm1_canonical_marketplace'), 'Migration 0001 recorded');
    assert(migrationNames.includes('0002_pm2_information_and_offers'), 'Migration 0002 recorded');
    assert(migrationNames.includes('0003_pm4_selection_disclosure_binding'), 'Migration 0003 recorded');
    assert(migrationNames.includes('0004_pm5_issued_policy_reconciliation_vault'), 'Migration 0004 recorded');
    assert(migrationNames.includes('0005_commercial_economics_foundation'), 'Migration 0005 recorded');

    // ------------------------------------------------------------------------
    // Part 4: API Namespace Isolation & PM-5 Non-Regression
    // ------------------------------------------------------------------------
    console.log('\n--- Test Group 4: API Namespace Separation & PM-5 Invariant ---');
    // PM-5 Invariant: No marketplace billing endpoints
    const resMarketplaceBilling = await request(server, 'POST', '/api/marketplace/billing/ledger', {});
    assert(resMarketplaceBilling.status === 404, 'Marketplace billing endpoint does not exist (404)');

    const resMarketplaceFees = await request(server, 'POST', '/api/marketplace/fees/settle', {});
    assert(resMarketplaceFees.status === 404, 'Marketplace fee settlement endpoint does not exist (404)');

    // CE Invariant: Commercial routes exist under /api/commercial/*
    const resPlans = await request(server, 'GET', '/api/commercial/plans');
    assert(resPlans.status === 200, 'GET /api/commercial/plans returns 200');
    assert(Array.isArray(resPlans.body.plans), 'Returns plans array');
    assert(resPlans.body.plans.length >= 2, 'Default seeded plans (Solo, Agency) available');

    // ------------------------------------------------------------------------
    // Part 5: Commercial Account & Agreement API (Authenticated Provider)
    // ------------------------------------------------------------------------
    console.log('\n--- Test Group 5: Provider Commercial Account & Agreement API ---');
    // Using authenticated user header for org_apex
    const apexHeaders = { 'x-provider-user-id': 'user_apex_1' };

    const resAccount = await request(server, 'GET', '/api/commercial/account', undefined, apexHeaders);
    assert(resAccount.status === 200, 'GET /api/commercial/account returns 200 for active provider');
    assert(resAccount.body.account.providerOrganizationId === 'org_apex', 'Account linked to authenticated provider org');
    assert(resAccount.body.account.status === 'ACTIVE', 'Account status is ACTIVE');

    const resAgreement = await request(server, 'GET', '/api/commercial/agreement', undefined, apexHeaders);
    assert(resAgreement.status === 200, 'GET /api/commercial/agreement returns 200');

    const resEntitlements = await request(server, 'GET', '/api/commercial/entitlements', undefined, apexHeaders);
    assert(resEntitlements.status === 200, 'GET /api/commercial/entitlements returns 200');
    assert(Array.isArray(resEntitlements.body.entitlements), 'Returns entitlements array');

    const resEvents = await request(server, 'GET', '/api/commercial/events', undefined, apexHeaders);
    assert(resEvents.status === 200, 'GET /api/commercial/events returns 200');
    assert(Array.isArray(resEvents.body.events), 'Returns events ledger array');

    const resValueSummary = await request(server, 'GET', '/api/commercial/value-summary', undefined, apexHeaders);
    assert(resValueSummary.status === 200, 'GET /api/commercial/value-summary returns 200');
    assert(resValueSummary.body.valueSummary.providerOrganizationId === 'org_apex', 'Value summary bound to provider org');
    assert(typeof resValueSummary.body.valueSummary.conversionRatios.engagementRate === 'number', 'Conversion ratios calculated');

    // ------------------------------------------------------------------------
    // Part 6: Impersonation Attack Prevention
    // ------------------------------------------------------------------------
    console.log('\n--- Test Group 6: Impersonation Attack Prevention ---');
    const attackHeaders = {
      'x-provider-user-id': 'user_apex_1',
      'x-provider-org-id': 'org_sierra' // Attempting to access Sierra's commercial account as Apex user
    };
    const resAttack = await request(server, 'GET', '/api/commercial/account', undefined, attackHeaders);
    assert(resAttack.status === 403, 'Impersonation attempt on commercial account rejected with 403 Forbidden');

    // ------------------------------------------------------------------------
    // Part 7: /api/tests/run Aggregation
    // ------------------------------------------------------------------------
    console.log('\n--- Test Group 7: Platform Test Suite Aggregation ---');
    const resAllTests = await request(server, 'GET', '/api/tests/run');
    assert(resAllTests.status === 200, 'GET /api/tests/run returns 200');
    assert(resAllTests.body.failed === 0, `All aggregated tests pass (0 failures out of ${resAllTests.body.total})`);
    const hasCeInResults = resAllTests.body.results.some((r: any) => r.name.includes('[CE-1]'));
    assert(hasCeInResults, 'Aggregated results include [CE-1] Commercial Economics suite');

    await testStore.close();

    console.log('\n============================================================');
    console.log('COMMERCIAL ECONOMICS (CE-1) VALIDATION COMPLETE: ALL PASS');
    console.log('============================================================\n');
  } finally {
    server.close();
    if (fs.existsSync(testDbDir)) {
      try {
        fs.rmSync(testDbDir, { recursive: true, force: true });
      } catch {}
    }
  }
}

runValidation()
  .then(() => process.exit(0))
  .catch((err) => {
    console.error('CE-1 Validation failed:', err);
    process.exit(1);
  });
