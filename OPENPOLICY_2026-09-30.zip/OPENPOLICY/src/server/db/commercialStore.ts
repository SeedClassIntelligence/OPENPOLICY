import { PGlite } from '@electric-sql/pglite';
import { postgresStore, PostgresStore } from './postgresStore';
import {
  CommercialAccount,
  CommercialPlan,
  CommercialPlanVersion,
  CommercialAgreement,
  ProviderEntitlement,
  CommercialEvent,
  BillableEvent
} from '../../types/insurance';

/**
 * CommercialStore — Persistence layer for Open Policy Commercial Economics (CE-1 through CE-5).
 * 
 * Operates over the shared PGlite database without mixing commercial models into
 * marketplace transaction entities.
 */
export class CommercialStore {
  private store: PostgresStore;

  constructor(store: PostgresStore = postgresStore) {
    this.store = store;
  }

  private async getClient(): Promise<PGlite> {
    return this.store.getPgClient();
  }

  // =========================================================================
  // CommercialAccount Methods
  // =========================================================================

  public async saveCommercialAccount(account: CommercialAccount): Promise<void> {
    const client = await this.getClient();
    await client.query(
      `INSERT INTO commercial_accounts (
        id, provider_organization_id, status, currency, external_billing_customer_ref, created_at, updated_at
      ) VALUES ($1, $2, $3, $4, $5, $6, $7)
      ON CONFLICT (id) DO UPDATE SET
        status = EXCLUDED.status,
        external_billing_customer_ref = EXCLUDED.external_billing_customer_ref,
        updated_at = EXCLUDED.updated_at;`,
      [
        account.id,
        account.providerOrganizationId,
        account.status,
        account.currency,
        account.externalBillingCustomerRef || null,
        account.createdAt,
        account.updatedAt
      ]
    );
  }

  public async getCommercialAccountByOrgId(providerOrganizationId: string): Promise<CommercialAccount | undefined> {
    const client = await this.getClient();
    const res = await client.query<{
      id: string;
      provider_organization_id: string;
      status: string;
      currency: string;
      external_billing_customer_ref: string | null;
      created_at: string;
      updated_at: string;
    }>(
      `SELECT * FROM commercial_accounts WHERE provider_organization_id = $1;`,
      [providerOrganizationId]
    );

    if (res.rows.length === 0) return undefined;
    const r = res.rows[0];
    return {
      id: r.id,
      providerOrganizationId: r.provider_organization_id,
      status: r.status as CommercialAccount['status'],
      currency: 'USD',
      externalBillingCustomerRef: r.external_billing_customer_ref || undefined,
      createdAt: r.created_at,
      updatedAt: r.updated_at
    };
  }

  public async getCommercialAccountById(id: string): Promise<CommercialAccount | undefined> {
    const client = await this.getClient();
    const res = await client.query<{
      id: string;
      provider_organization_id: string;
      status: string;
      currency: string;
      external_billing_customer_ref: string | null;
      created_at: string;
      updated_at: string;
    }>(
      `SELECT * FROM commercial_accounts WHERE id = $1;`,
      [id]
    );

    if (res.rows.length === 0) return undefined;
    const r = res.rows[0];
    return {
      id: r.id,
      providerOrganizationId: r.provider_organization_id,
      status: r.status as CommercialAccount['status'],
      currency: 'USD',
      externalBillingCustomerRef: r.external_billing_customer_ref || undefined,
      createdAt: r.created_at,
      updatedAt: r.updated_at
    };
  }

  // =========================================================================
  // CommercialPlan & PlanVersion Methods
  // =========================================================================

  public async saveCommercialPlan(plan: CommercialPlan): Promise<void> {
    const client = await this.getClient();
    await client.query(
      `INSERT INTO commercial_plans (
        id, code, display_name, provider_segment, status, created_at
      ) VALUES ($1, $2, $3, $4, $5, $6)
      ON CONFLICT (id) DO UPDATE SET
        display_name = EXCLUDED.display_name,
        status = EXCLUDED.status;`,
      [
        plan.id,
        plan.code,
        plan.displayName,
        plan.providerSegment,
        plan.status,
        plan.createdAt
      ]
    );
  }

  public async getCommercialPlanByCode(code: string): Promise<CommercialPlan | undefined> {
    const client = await this.getClient();
    const res = await client.query<{
      id: string;
      code: string;
      display_name: string;
      provider_segment: string;
      status: string;
      created_at: string;
    }>(
      `SELECT * FROM commercial_plans WHERE code = $1;`,
      [code]
    );

    if (res.rows.length === 0) return undefined;
    const r = res.rows[0];
    return {
      id: r.id,
      code: r.code,
      displayName: r.display_name,
      providerSegment: r.provider_segment as CommercialPlan['providerSegment'],
      status: r.status as CommercialPlan['status'],
      createdAt: r.created_at
    };
  }

  public async getCommercialPlanById(id: string): Promise<CommercialPlan | undefined> {
    const client = await this.getClient();
    const res = await client.query<{
      id: string;
      code: string;
      display_name: string;
      provider_segment: string;
      status: string;
      created_at: string;
    }>(
      `SELECT * FROM commercial_plans WHERE id = $1;`,
      [id]
    );

    if (res.rows.length === 0) return undefined;
    const r = res.rows[0];
    return {
      id: r.id,
      code: r.code,
      displayName: r.display_name,
      providerSegment: r.provider_segment as CommercialPlan['providerSegment'],
      status: r.status as CommercialPlan['status'],
      createdAt: r.created_at
    };
  }

  public async listActivePlans(): Promise<CommercialPlan[]> {
    const client = await this.getClient();
    const res = await client.query<{
      id: string;
      code: string;
      display_name: string;
      provider_segment: string;
      status: string;
      created_at: string;
    }>(
      `SELECT * FROM commercial_plans WHERE status = 'ACTIVE' ORDER BY created_at ASC;`
    );

    return res.rows.map(r => ({
      id: r.id,
      code: r.code,
      displayName: r.display_name,
      providerSegment: r.provider_segment as CommercialPlan['providerSegment'],
      status: r.status as CommercialPlan['status'],
      createdAt: r.created_at
    }));
  }

  public async saveCommercialPlanVersion(version: CommercialPlanVersion): Promise<void> {
    const client = await this.getClient();
    await client.query(
      `INSERT INTO commercial_plan_versions (
        id, plan_id, version, effective_from, effective_until, billing_interval,
        recurring_fee_cents, currency, terms_snapshot, created_at
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
      ON CONFLICT (id) DO NOTHING;`, // Immutable: never mutate historical versions
      [
        version.id,
        version.planId,
        version.version,
        version.effectiveFrom,
        version.effectiveUntil || null,
        version.billingInterval,
        version.recurringFeeCents,
        version.currency,
        JSON.stringify(version.termsSnapshot || {}),
        version.createdAt
      ]
    );
  }

  public async getCommercialPlanVersion(id: string): Promise<CommercialPlanVersion | undefined> {
    const client = await this.getClient();
    const res = await client.query<{
      id: string;
      plan_id: string;
      version: number;
      effective_from: string;
      effective_until: string | null;
      billing_interval: string;
      recurring_fee_cents: number;
      currency: string;
      terms_snapshot: string;
      created_at: string;
    }>(
      `SELECT * FROM commercial_plan_versions WHERE id = $1;`,
      [id]
    );

    if (res.rows.length === 0) return undefined;
    const r = res.rows[0];
    return {
      id: r.id,
      planId: r.plan_id,
      version: r.version,
      effectiveFrom: r.effective_from,
      effectiveUntil: r.effective_until || undefined,
      billingInterval: r.billing_interval as CommercialPlanVersion['billingInterval'],
      recurringFeeCents: r.recurring_fee_cents,
      currency: 'USD',
      termsSnapshot: JSON.parse(r.terms_snapshot || '{}'),
      createdAt: r.created_at
    };
  }

  public async getLatestPlanVersion(planId: string): Promise<CommercialPlanVersion | undefined> {
    const client = await this.getClient();
    const res = await client.query<{
      id: string;
      plan_id: string;
      version: number;
      effective_from: string;
      effective_until: string | null;
      billing_interval: string;
      recurring_fee_cents: number;
      currency: string;
      terms_snapshot: string;
      created_at: string;
    }>(
      `SELECT * FROM commercial_plan_versions WHERE plan_id = $1 ORDER BY version DESC LIMIT 1;`,
      [planId]
    );

    if (res.rows.length === 0) return undefined;
    const r = res.rows[0];
    return {
      id: r.id,
      planId: r.plan_id,
      version: r.version,
      effectiveFrom: r.effective_from,
      effectiveUntil: r.effective_until || undefined,
      billingInterval: r.billing_interval as CommercialPlanVersion['billingInterval'],
      recurringFeeCents: r.recurring_fee_cents,
      currency: 'USD',
      termsSnapshot: JSON.parse(r.terms_snapshot || '{}'),
      createdAt: r.created_at
    };
  }

  // =========================================================================
  // CommercialAgreement Methods
  // =========================================================================

  public async saveCommercialAgreement(agreement: CommercialAgreement): Promise<void> {
    const client = await this.getClient();
    await client.query(
      `INSERT INTO commercial_agreements (
        id, commercial_account_id, provider_organization_id, plan_version_id,
        status, starts_at, ends_at, accepted_at, created_at
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
      ON CONFLICT (id) DO UPDATE SET
        status = EXCLUDED.status,
        ends_at = EXCLUDED.ends_at,
        accepted_at = EXCLUDED.accepted_at;`,
      [
        agreement.id,
        agreement.commercialAccountId,
        agreement.providerOrganizationId,
        agreement.planVersionId,
        agreement.status,
        agreement.startsAt,
        agreement.endsAt || null,
        agreement.acceptedAt || null,
        agreement.createdAt
      ]
    );
  }

  public async getActiveAgreementForOrg(providerOrganizationId: string): Promise<CommercialAgreement | undefined> {
    const client = await this.getClient();
    const res = await client.query<{
      id: string;
      commercial_account_id: string;
      provider_organization_id: string;
      plan_version_id: string;
      status: string;
      starts_at: string;
      ends_at: string | null;
      accepted_at: string | null;
      created_at: string;
    }>(
      `SELECT * FROM commercial_agreements
       WHERE provider_organization_id = $1 AND status = 'ACTIVE'
       ORDER BY created_at DESC LIMIT 1;`,
      [providerOrganizationId]
    );

    if (res.rows.length === 0) return undefined;
    const r = res.rows[0];
    return {
      id: r.id,
      commercialAccountId: r.commercial_account_id,
      providerOrganizationId: r.provider_organization_id,
      planVersionId: r.plan_version_id,
      status: r.status as CommercialAgreement['status'],
      startsAt: r.starts_at,
      endsAt: r.ends_at || undefined,
      acceptedAt: r.accepted_at || undefined,
      createdAt: r.created_at
    };
  }

  public async getCommercialAgreementById(id: string): Promise<CommercialAgreement | undefined> {
    const client = await this.getClient();
    const res = await client.query<{
      id: string;
      commercial_account_id: string;
      provider_organization_id: string;
      plan_version_id: string;
      status: string;
      starts_at: string;
      ends_at: string | null;
      accepted_at: string | null;
      created_at: string;
    }>(
      `SELECT * FROM commercial_agreements WHERE id = $1;`,
      [id]
    );

    if (res.rows.length === 0) return undefined;
    const r = res.rows[0];
    return {
      id: r.id,
      commercialAccountId: r.commercial_account_id,
      providerOrganizationId: r.provider_organization_id,
      planVersionId: r.plan_version_id,
      status: r.status as CommercialAgreement['status'],
      startsAt: r.starts_at,
      endsAt: r.ends_at || undefined,
      acceptedAt: r.accepted_at || undefined,
      createdAt: r.created_at
    };
  }

  // =========================================================================
  // ProviderEntitlement Methods
  // =========================================================================

  public async saveProviderEntitlement(entitlement: ProviderEntitlement): Promise<void> {
    const client = await this.getClient();
    await client.query(
      `INSERT INTO provider_entitlements (
        id, provider_organization_id, commercial_agreement_id, entitlement_type,
        limit_val, scope, effective_from, effective_until, created_at
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
      ON CONFLICT (id) DO UPDATE SET
        limit_val = EXCLUDED.limit_val,
        scope = EXCLUDED.scope,
        effective_until = EXCLUDED.effective_until;`,
      [
        entitlement.id,
        entitlement.providerOrganizationId,
        entitlement.commercialAgreementId,
        entitlement.entitlementType,
        entitlement.limit ?? null,
        entitlement.scope ? JSON.stringify(entitlement.scope) : null,
        entitlement.effectiveFrom,
        entitlement.effectiveUntil || null,
        entitlement.createdAt
      ]
    );
  }

  public async getEntitlementsForOrg(providerOrganizationId: string): Promise<ProviderEntitlement[]> {
    const client = await this.getClient();
    const res = await client.query<{
      id: string;
      provider_organization_id: string;
      commercial_agreement_id: string;
      entitlement_type: string;
      limit_val: number | null;
      scope: string | null;
      effective_from: string;
      effective_until: string | null;
      created_at: string;
    }>(
      `SELECT * FROM provider_entitlements WHERE provider_organization_id = $1 ORDER BY created_at ASC;`,
      [providerOrganizationId]
    );

    return res.rows.map(r => ({
      id: r.id,
      providerOrganizationId: r.provider_organization_id,
      commercialAgreementId: r.commercial_agreement_id,
      entitlementType: r.entitlement_type as ProviderEntitlement['entitlementType'],
      limit: r.limit_val ?? undefined,
      scope: r.scope ? JSON.parse(r.scope) : undefined,
      effectiveFrom: r.effective_from,
      effectiveUntil: r.effective_until || undefined,
      createdAt: r.created_at
    }));
  }

  // =========================================================================
  // CommercialEvent Ledger Methods (Append-Only)
  // =========================================================================

  public async recordCommercialEvent(event: CommercialEvent): Promise<boolean> {
    const client = await this.getClient();
    try {
      await client.query(
        `INSERT INTO commercial_events (
          id, provider_organization_id, event_type, source_entity_type, source_entity_id,
          challenge_id, competition_id, commercial_agreement_id, commercial_plan_version_id,
          occurred_at, metadata, idempotency_key, event_hash
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)
        ON CONFLICT (idempotency_key) DO NOTHING;`,
        [
          event.id,
          event.providerOrganizationId,
          event.eventType,
          event.sourceEntityType,
          event.sourceEntityId,
          event.challengeId || null,
          event.competitionId || null,
          event.commercialAgreementId || null,
          event.commercialPlanVersionId || null,
          event.occurredAt,
          event.metadata ? JSON.stringify(event.metadata) : null,
          event.idempotencyKey,
          event.eventHash
        ]
      );
      return true;
    } catch {
      return false;
    }
  }

  public async getCommercialEventsForOrg(
    providerOrganizationId: string,
    limit = 100
  ): Promise<CommercialEvent[]> {
    const client = await this.getClient();
    const res = await client.query<{
      id: string;
      provider_organization_id: string;
      event_type: string;
      source_entity_type: string;
      source_entity_id: string;
      challenge_id: string | null;
      competition_id: string | null;
      commercial_agreement_id: string | null;
      commercial_plan_version_id: string | null;
      occurred_at: string;
      metadata: string | null;
      idempotency_key: string;
      event_hash: string;
    }>(
      `SELECT * FROM commercial_events
       WHERE provider_organization_id = $1
       ORDER BY occurred_at DESC
       LIMIT $2;`,
      [providerOrganizationId, limit]
    );

    return res.rows.map(r => ({
      id: r.id,
      providerOrganizationId: r.provider_organization_id,
      eventType: r.event_type as CommercialEvent['eventType'],
      sourceEntityType: r.source_entity_type,
      sourceEntityId: r.source_entity_id,
      challengeId: r.challenge_id || undefined,
      competitionId: r.competition_id || undefined,
      commercialAgreementId: r.commercial_agreement_id || undefined,
      commercialPlanVersionId: r.commercial_plan_version_id || undefined,
      occurredAt: r.occurred_at,
      metadata: r.metadata ? JSON.parse(r.metadata) : undefined,
      idempotencyKey: r.idempotency_key,
      eventHash: r.event_hash
    }));
  }

  public async getEventCountsByType(providerOrganizationId: string): Promise<Record<string, number>> {
    const client = await this.getClient();
    const res = await client.query<{
      event_type: string;
      cnt: string;
    }>(
      `SELECT event_type, COUNT(*) as cnt
       FROM commercial_events
       WHERE provider_organization_id = $1
       GROUP BY event_type;`,
      [providerOrganizationId]
    );

    const counts: Record<string, number> = {};
    for (const r of res.rows) {
      counts[r.event_type] = parseInt(r.cnt, 10);
    }
    return counts;
  }

  // =========================================================================
  // BillableEvent Methods
  // =========================================================================

  public async saveBillableEvent(billable: BillableEvent): Promise<boolean> {
    const client = await this.getClient();
    try {
      await client.query(
        `INSERT INTO billable_events (
          id, commercial_event_id, provider_organization_id, commercial_agreement_id,
          charge_code, quantity, unit_price_cents, amount_cents, currency, status,
          rated_at, pricing_snapshot, idempotency_key
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)
        ON CONFLICT (idempotency_key) DO NOTHING;`,
        [
          billable.id,
          billable.commercialEventId,
          billable.providerOrganizationId,
          billable.commercialAgreementId,
          billable.chargeCode,
          billable.quantity,
          billable.unitPriceCents,
          billable.amountCents,
          billable.currency,
          billable.status,
          billable.ratedAt,
          JSON.stringify(billable.pricingSnapshot || {}),
          billable.idempotencyKey
        ]
      );
      return true;
    } catch {
      return false;
    }
  }

  public async getBillableEventsForOrg(providerOrganizationId: string): Promise<BillableEvent[]> {
    const client = await this.getClient();
    const res = await client.query<{
      id: string;
      commercial_event_id: string;
      provider_organization_id: string;
      commercial_agreement_id: string;
      charge_code: string;
      quantity: number;
      unit_price_cents: number;
      amount_cents: number;
      currency: string;
      status: string;
      rated_at: string;
      pricing_snapshot: string;
      idempotency_key: string;
    }>(
      `SELECT * FROM billable_events
       WHERE provider_organization_id = $1
       ORDER BY rated_at DESC;`,
      [providerOrganizationId]
    );

    return res.rows.map(r => ({
      id: r.id,
      commercialEventId: r.commercial_event_id,
      providerOrganizationId: r.provider_organization_id,
      commercialAgreementId: r.commercial_agreement_id,
      chargeCode: r.charge_code,
      quantity: r.quantity,
      unitPriceCents: r.unit_price_cents,
      amountCents: r.amount_cents,
      currency: 'USD',
      status: r.status as BillableEvent['status'],
      ratedAt: r.rated_at,
      pricingSnapshot: JSON.parse(r.pricing_snapshot || '{}'),
      idempotencyKey: r.idempotency_key
    }));
  }

  public async seedCanonicalPlans(): Promise<void> {
    const existingSolo = await this.getCommercialPlanByCode('PLAN_SOLO');
    if (!existingSolo) {
      await this.saveCommercialPlan({
        id: 'plan_solo_producer',
        code: 'PLAN_SOLO',
        displayName: 'Solo Producer Access',
        providerSegment: 'SOLO',
        status: 'ACTIVE',
        createdAt: '2026-01-01T00:00:00Z'
      });
      await this.saveCommercialPlanVersion({
        id: 'cpv_plan_solo_producer_v1',
        planId: 'plan_solo_producer',
        version: 1,
        effectiveFrom: '2026-01-01T00:00:00Z',
        billingInterval: 'MONTHLY',
        recurringFeeCents: 19900,
        currency: 'USD',
        termsSnapshot: {
          includedProducerSeats: 1,
          includedJurisdictions: 1,
          includedVpoCapacity: 50,
          includedEngagementCapacity: 25,
          includedAuthorizedConnections: 10,
          authorizedConnectionUnitPriceCents: 2500,
          boundAcquisitionUnitPriceCents: 0
        },
        createdAt: '2026-01-01T00:00:00Z'
      });
    }

    const existingAgency = await this.getCommercialPlanByCode('PLAN_AGENCY');
    if (!existingAgency) {
      await this.saveCommercialPlan({
        id: 'plan_agency_growth',
        code: 'PLAN_AGENCY',
        displayName: 'Agency Growth Partner',
        providerSegment: 'AGENCY',
        status: 'ACTIVE',
        createdAt: '2026-01-01T00:00:00Z'
      });
      await this.saveCommercialPlanVersion({
        id: 'cpv_plan_agency_growth_v1',
        planId: 'plan_agency_growth',
        version: 1,
        effectiveFrom: '2026-01-01T00:00:00Z',
        billingInterval: 'MONTHLY',
        recurringFeeCents: 49900,
        currency: 'USD',
        termsSnapshot: {
          includedProducerSeats: 5,
          includedJurisdictions: 3,
          includedVpoCapacity: 200,
          includedEngagementCapacity: 100,
          includedAuthorizedConnections: 35,
          authorizedConnectionUnitPriceCents: 2000,
          boundAcquisitionUnitPriceCents: 0
        },
        createdAt: '2026-01-01T00:00:00Z'
      });
    }
  }
}

export const commercialStore = new CommercialStore();
