/**
 * Commercial Economics Domain & Neutrality Test Suite (CE-1)
 * 
 * Verifies:
 * 1. COMMERCIAL_NEUTRALITY: Provider commercial plan has ZERO influence on
 *    offer comparison, qualification, sorting, or selection.
 * 2. Immutable CommercialPlanVersion pricing and snapshots.
 * 3. Distinct CommercialAccount lifecycle independent of regulatory ProviderOrganization.
 * 4. Idempotent CommercialEvent recording with deterministic keys.
 * 5. Entitlement capacity evaluation without affecting entered competition logic.
 * 6. Pure deterministic rating engine for billable events.
 * 7. Factual value summary conversion calculations.
 */

import {
  createCommercialAccount,
  createCommercialPlanVersion,
  createCommercialAgreement,
  deriveEntitlementsFromPlanVersion,
  checkEntitlementCapacity,
  buildCommercialEvent,
  rateCommercialEvent,
  calculateValueSummary
} from './commercialEconomicsEngine';

import { compareOfferAgainstBaseline } from './comparisonEngine';
import {
  CommercialPlan,
  CommercialPlanVersion,
  CommercialAgreement,
  CoverageBaseline,
  Offer
} from '../types/insurance';

export interface TestResult {
  name: string;
  passed: boolean;
  error?: string;
}

export function runCommercialEconomicsTestSuite(): {
  passed: number;
  failed: number;
  total: number;
  results: TestResult[];
} {
  const results: TestResult[] = [];

  function test(name: string, fn: () => void) {
    try {
      fn();
      results.push({ name: `[CE-1] ${name}`, passed: true });
    } catch (e: any) {
      results.push({ name: `[CE-1] ${name}`, passed: false, error: e.message });
    }
  }

  function assert(condition: boolean, msg: string) {
    if (!condition) throw new Error(msg);
  }

  // -------------------------------------------------------------------------
  // Test 1: CommercialAccount creation & separation from ProviderOrganization
  // -------------------------------------------------------------------------
  test('CommercialAccount is decoupled from ProviderOrganization regulatory identity', () => {
    const orgId = 'org_apex';
    const account = createCommercialAccount({
      providerOrganizationId: orgId,
      externalBillingCustomerRef: 'cus_stripe_123',
      status: 'ACTIVE'
    });

    assert(account.providerOrganizationId === orgId, 'Links to ProviderOrganization ID');
    assert(account.status === 'ACTIVE', 'Account status is ACTIVE');
    assert(account.currency === 'USD', 'Currency is USD');
    assert(account.externalBillingCustomerRef === 'cus_stripe_123', 'External ref preserved');
    assert(!!account.createdAt, 'Timestamp generated');
  });

  // -------------------------------------------------------------------------
  // Test 2: CommercialPlanVersion immutability & historical reproducibility
  // -------------------------------------------------------------------------
  test('CommercialPlanVersion is immutable and preserves terms snapshot', () => {
    const planVersion = createCommercialPlanVersion({
      planId: 'plan_agency_growth',
      version: 1,
      effectiveFrom: '2026-01-01T00:00:00Z',
      billingInterval: 'MONTHLY',
      recurringFeeCents: 49900, // $499.00
      termsSnapshot: {
        includedProducerSeats: 5,
        includedJurisdictions: 3,
        includedVpoCapacity: 100,
        includedAuthorizedConnections: 25,
        authorizedConnectionUnitPriceCents: 2500
      }
    });

    assert(planVersion.recurringFeeCents === 49900, 'Recurring fee is $499.00 in cents');
    assert(planVersion.termsSnapshot.includedProducerSeats === 5, 'Included seats recorded');
    assert(planVersion.termsSnapshot.includedAuthorizedConnections === 25, 'Included connections recorded');

    // Attempt mutation on frozen snapshot must throw in strict mode
    let threw = false;
    try {
      (planVersion.termsSnapshot as any).includedProducerSeats = 99;
    } catch {
      threw = true;
    }
    assert(threw || planVersion.termsSnapshot.includedProducerSeats === 5, 'Terms snapshot is immutable');
  });

  // -------------------------------------------------------------------------
  // Test 3: Entitlement derivation & capacity enforcement
  // -------------------------------------------------------------------------
  test('ProviderEntitlements derived from plan version enforce capacity limits', () => {
    const agreement = createCommercialAgreement({
      commercialAccountId: 'cac_org_apex',
      providerOrganizationId: 'org_apex',
      planVersionId: 'cpv_plan_agency_growth_v1',
      startsAt: '2026-01-01T00:00:00Z'
    });

    const planVersion = createCommercialPlanVersion({
      planId: 'plan_agency_growth',
      version: 1,
      effectiveFrom: '2026-01-01T00:00:00Z',
      billingInterval: 'MONTHLY',
      recurringFeeCents: 49900,
      termsSnapshot: {
        includedVpoCapacity: 50,
        includedEngagementCapacity: 20
      }
    });

    const entitlements = deriveEntitlementsFromPlanVersion({ agreement, planVersion });
    assert(entitlements.length === 2, 'Two entitlements derived from terms snapshot');

    // Check capacity: below limit
    const check1 = checkEntitlementCapacity({
      entitlements,
      entitlementType: 'VPO_ENGAGEMENT_CAPACITY',
      currentUsage: 15
    });
    assert(check1.allowed === true, 'Under limit is allowed');

    // Check capacity: at limit
    const check2 = checkEntitlementCapacity({
      entitlements,
      entitlementType: 'VPO_ENGAGEMENT_CAPACITY',
      currentUsage: 20
    });
    assert(check2.allowed === false, 'At limit is disallowed');
    assert(check2.limit === 20, 'Limit is 20');
  });

  // -------------------------------------------------------------------------
  // Test 4: CommercialEvent ledger with deterministic hash & idempotency
  // -------------------------------------------------------------------------
  test('CommercialEvent produces verifiable SHA-256 hash and deterministic idempotency key', () => {
    const event = buildCommercialEvent({
      providerOrganizationId: 'org_apex',
      eventType: 'AUTHORIZED_CONNECTION',
      sourceEntityType: 'DisclosureEvent',
      sourceEntityId: 'dsc_12345',
      challengeId: 'CHAL-NV-49281',
      competitionId: 'COMP-NV-49281'
    });

    assert(event.eventType === 'AUTHORIZED_CONNECTION', 'Event type is AUTHORIZED_CONNECTION');
    assert(event.idempotencyKey === 'AUTHORIZED_CONNECTION:DisclosureEvent:dsc_12345', 'Deterministic idempotency key');
    assert(event.eventHash.length === 64, 'Event hash is 64-char hex SHA-256');

    // Idempotent recreation produces identical key
    const duplicate = buildCommercialEvent({
      providerOrganizationId: 'org_apex',
      eventType: 'AUTHORIZED_CONNECTION',
      sourceEntityType: 'DisclosureEvent',
      sourceEntityId: 'dsc_12345'
    });
    assert(duplicate.idempotencyKey === event.idempotencyKey, 'Re-run produces identical idempotency key');
  });

  // -------------------------------------------------------------------------
  // Test 5: Deterministic Rating Engine — Zero-dollar vs billable events
  // -------------------------------------------------------------------------
  test('Deterministic rating engine respects included capacity before charging', () => {
    const planVersion = createCommercialPlanVersion({
      planId: 'plan_agency_growth',
      version: 1,
      effectiveFrom: '2026-01-01T00:00:00Z',
      billingInterval: 'MONTHLY',
      recurringFeeCents: 49900,
      termsSnapshot: {
        includedAuthorizedConnections: 10,
        authorizedConnectionUnitPriceCents: 2000 // $20.00
      }
    });

    const agreement = createCommercialAgreement({
      commercialAccountId: 'cac_org_apex',
      providerOrganizationId: 'org_apex',
      planVersionId: planVersion.id,
      startsAt: '2026-01-01T00:00:00Z'
    });

    const event = buildCommercialEvent({
      providerOrganizationId: 'org_apex',
      eventType: 'AUTHORIZED_CONNECTION',
      sourceEntityType: 'DisclosureEvent',
      sourceEntityId: 'dsc_001'
    });

    // Connection 5 (within included 10)
    const ratingIncluded = rateCommercialEvent({
      event,
      agreement,
      planVersion,
      priorUsageCount: 4
    });
    assert(ratingIncluded.billable === false, 'Under included capacity is not billable');
    assert(ratingIncluded.amountCents === 0, 'Zero dollar amount for included capacity');

    // Connection 11 (above included 10)
    const ratingOverage = rateCommercialEvent({
      event,
      agreement,
      planVersion,
      priorUsageCount: 10
    });
    assert(ratingOverage.billable === true, 'Overage is billable');
    assert(ratingOverage.amountCents === 2000, 'Unit price charged ($20.00)');
  });

  // -------------------------------------------------------------------------
  // Test 6: Value Summary Funnel Calculation
  // -------------------------------------------------------------------------
  test('Value summary computes factual conversion ratios without ranking', () => {
    const summary = calculateValueSummary({
      providerOrganizationId: 'org_apex',
      from: '2026-09-01T00:00:00Z',
      to: '2026-09-30T23:59:59Z',
      counts: {
        VPO_AVAILABLE: 100,
        VPO_VIEWED: 80,
        VPO_ENGAGED: 50,
        PROPOSITION_SUBMITTED: 40,
        CONSUMER_SELECTED: 20,
        AUTHORIZED_CONNECTION: 16,
        BOUND_ACQUISITION: 12,
        VERIFIED_BOUND_OUTCOME: 10
      }
    });

    assert(summary.vposAvailable === 100, 'VPOs available count correct');
    assert(summary.conversionRatios.engagementRate === 0.5, 'Engagement rate is 50/100 = 0.5');
    assert(summary.conversionRatios.selectionRate === 0.4, 'Selection rate is 20/50 = 0.4');
    assert(summary.conversionRatios.authorizationRate === 0.8, 'Authorization rate is 16/20 = 0.8');
    assert(summary.conversionRatios.bindRate === 0.75, 'Bind rate is 12/16 = 0.75');
    assert(summary.conversionRatios.verificationRate === 0.833, 'Verification rate is 10/12 = 0.833');
  });

  // -------------------------------------------------------------------------
  // Test 7: COMMERCIAL_NEUTRALITY FIREWALL INVARIANT (Most Critical Test)
  // -------------------------------------------------------------------------
  test('COMMERCIAL_NEUTRALITY: Provider commercial plan differences produce IDENTICAL comparison results', () => {
    // Construct mock baseline
    const mockBaseline: CoverageBaseline = {
      id: 'BL-TEST-NEUTRALITY',
      policyId: 'POL-TEST-1',
      version: 1,
      carrier: 'State Farm Mutual',
      effectiveDate: '2026-01-01',
      expirationDate: '2027-01-01',
      baselineAnnualPremium: 2000,
      baselineMonthlyPremium: 167,
      vehicle: {
        year: 2022,
        make: 'Toyota',
        model: 'Camry',
        vin: '123',
        usage: 'COMMUTE',
        annualMileage: 12000,
        garagingZip: '89101',
        ownership: 'OWNED'
      },
      coverages: [
        { id: 'bi_base', code: 'BODILY_INJURY', name: 'Bodily Injury', category: 'LIABILITY', perPersonLimit: 100000, perAccidentLimit: 300000, isIncluded: true },
        { id: 'pd_base', code: 'PROPERTY_DAMAGE', name: 'Property Damage', category: 'LIABILITY', propertyLimit: 100000, isIncluded: true }
      ],
      verifiedAt: '2026-01-01T00:00:00Z',
      verifiedBy: 'Consumer'
    };

    // Provider A: Solo plan ($0 or $99)
    const offerFromProviderA: Offer = {
      id: 'OFF-PROV-A',
      challengeId: 'CHAL-TEST-1',
      providerId: 'org_solo_agent',
      providerName: 'Solo Agent Joe',
      providerLicense: 'NV-LIC-100',
      carrier: 'Progressive Northern',
      quoteNumber: 'Q-SOLO-1',
      annualPremium: 1800,
      monthlyPremium: 150,
      termMonths: 12,
      effectiveDate: '2026-01-01',
      expirationDate: '2027-01-01',
      supportingQuoteDocName: 'quote_solo.pdf',
      submittedAt: '2026-01-01T00:00:00Z',
      discrepanciesDetected: false,
      status: 'VALIDATED',
      round: 'ROUND_1_OPEN',
      version: 1,
      coverages: [
        { id: 'bi_off_a', code: 'BODILY_INJURY', name: 'Bodily Injury', category: 'LIABILITY', perPersonLimit: 100000, perAccidentLimit: 300000, isIncluded: true },
        { id: 'pd_off_a', code: 'PROPERTY_DAMAGE', name: 'Property Damage', category: 'LIABILITY', propertyLimit: 100000, isIncluded: true }
      ]
    };

    // Provider B: Enterprise plan ($5,000/mo) submitting identical insurance proposition
    const offerFromProviderB: Offer = {
      id: 'OFF-PROV-B',
      challengeId: 'CHAL-TEST-1',
      providerId: 'org_enterprise_national',
      providerName: 'National Megacorp Carrier',
      providerLicense: 'NV-LIC-200',
      carrier: 'Progressive Northern',
      quoteNumber: 'Q-ENT-1',
      annualPremium: 1800,
      monthlyPremium: 150,
      termMonths: 12,
      effectiveDate: '2026-01-01',
      expirationDate: '2027-01-01',
      supportingQuoteDocName: 'quote_ent.pdf',
      submittedAt: '2026-01-01T00:00:00Z',
      discrepanciesDetected: false,
      status: 'VALIDATED',
      round: 'ROUND_1_OPEN',
      version: 1,
      coverages: [
        { id: 'bi_off_b', code: 'BODILY_INJURY', name: 'Bodily Injury', category: 'LIABILITY', perPersonLimit: 100000, perAccidentLimit: 300000, isIncluded: true },
        { id: 'pd_off_b', code: 'PROPERTY_DAMAGE', name: 'Property Damage', category: 'LIABILITY', propertyLimit: 100000, isIncluded: true }
      ]
    };

    const dummyRequirements = {
      id: 'req-neutrality',
      ruleSummary: 'Beat my price without cutting protection',
      minAnnualSavings: 50,
      maxCollisionDeductible: 500,
      maxCompDeductible: 500,
      mustIncludeRental: false,
      mustIncludeRoadside: false
    };

    // Run deterministic comparison engine
    const compA = compareOfferAgainstBaseline(mockBaseline, dummyRequirements, offerFromProviderA);
    const compB = compareOfferAgainstBaseline(mockBaseline, dummyRequirements, offerFromProviderB);

    // Verify absolute equality of comparison outcomes
    assert(compA.classification === compB.classification, 'Classifications must be IDENTICAL');
    assert(compA.annualSavings === compB.annualSavings, 'Annual savings must be IDENTICAL');
    assert(compA.meetsConsumerRequirements === compB.meetsConsumerRequirements, 'Requirement satisfaction must be IDENTICAL');
    assert(compA.fieldComparisons.length === compB.fieldComparisons.length, 'Field comparisons must be IDENTICAL');

    // Assert that NO commercial plan attribute leaked into comparison output
    const keysA = Object.keys(compA);
    const hasCommercialLeaking = keysA.some(k =>
      k.toLowerCase().includes('plan') ||
      k.toLowerCase().includes('commercial') ||
      k.toLowerCase().includes('fee') ||
      k.toLowerCase().includes('account') ||
      k.toLowerCase().includes('agreement')
    );
    assert(!hasCommercialLeaking, 'No commercial attributes exist in OfferComparison object');
  });

  const passed = results.filter(r => r.passed).length;
  const failed = results.filter(r => !r.passed).length;
  return { passed, failed, total: results.length, results };
}

// Direct CLI execution
if (process.argv[1] && process.argv[1].endsWith('commercialEconomics.test.ts')) {
  const { passed, failed, total, results } = runCommercialEconomicsTestSuite();
  console.log(`\n========================================`);
  console.log(`Commercial Economics Suite: ${passed}/${total} PASSED (${failed} FAILED)`);
  console.log(`========================================`);
  results.forEach(r => {
    console.log(`[${r.passed ? 'PASS' : 'FAIL'}] ${r.name}${r.error ? ` -> ${r.error}` : ''}`);
  });
}
