/**
 * Open Policy Commercial Economics Engine (CE-1 through CE-4)
 * 
 * Formal Invariants:
 * 1. COMMERCIAL_NEUTRALITY: No commercial object may be read by comparison,
 *    competition evaluation, qualification, sorting, selection, disclosure, or PM-5 reconciliation.
 * 2. Immutable Pricing: CommercialPlanVersion pricing and terms are strictly immutable.
 * 3. Idempotent Commercial Events: Event ledger is append-only with deterministic keys.
 * 4. Distinct Identities: ProviderOrganization (marketplace/regulatory) is decoupled
 *    from CommercialAccount (contractual/commercial).
 * 5. Deterministic Rating: Pure functions evaluate agreements without network or database I/O.
 */

import crypto from 'crypto';
import {
  CommercialAccount,
  CommercialPlan,
  CommercialPlanVersion,
  CommercialAgreement,
  ProviderEntitlement,
  EntitlementType,
  CommercialEvent,
  CommercialEventType,
  BillableEvent,
  RatingDecision,
  CommercialValueSummary
} from '../types/insurance';

/**
 * Creates a new CommercialAccount for a ProviderOrganization.
 */
export function createCommercialAccount(params: {
  providerOrganizationId: string;
  externalBillingCustomerRef?: string;
  status?: CommercialAccount['status'];
  now?: string;
}): CommercialAccount {
  const timestamp = params.now || new Date().toISOString();
  return {
    id: `cac_${params.providerOrganizationId}`,
    providerOrganizationId: params.providerOrganizationId,
    status: params.status || 'ACTIVE',
    currency: 'USD',
    externalBillingCustomerRef: params.externalBillingCustomerRef,
    createdAt: timestamp,
    updatedAt: timestamp
  };
}

/**
 * Creates an immutable CommercialPlanVersion.
 */
export function createCommercialPlanVersion(params: {
  planId: string;
  version: number;
  effectiveFrom: string;
  effectiveUntil?: string;
  billingInterval: CommercialPlanVersion['billingInterval'];
  recurringFeeCents: number;
  termsSnapshot: CommercialPlanVersion['termsSnapshot'];
  now?: string;
}): CommercialPlanVersion {
  return {
    id: `cpv_${params.planId}_v${params.version}`,
    planId: params.planId,
    version: params.version,
    effectiveFrom: params.effectiveFrom,
    effectiveUntil: params.effectiveUntil,
    billingInterval: params.billingInterval,
    recurringFeeCents: params.recurringFeeCents,
    currency: 'USD',
    termsSnapshot: Object.freeze({ ...params.termsSnapshot }),
    createdAt: params.now || new Date().toISOString()
  };
}

/**
 * Creates a contractual CommercialAgreement binding an account to a plan version.
 */
export function createCommercialAgreement(params: {
  commercialAccountId: string;
  providerOrganizationId: string;
  planVersionId: string;
  startsAt: string;
  endsAt?: string;
  acceptedAt?: string;
  status?: CommercialAgreement['status'];
  now?: string;
}): CommercialAgreement {
  const timestamp = params.now || new Date().toISOString();
  return {
    id: `cag_${params.providerOrganizationId}_${Date.now()}`,
    commercialAccountId: params.commercialAccountId,
    providerOrganizationId: params.providerOrganizationId,
    planVersionId: params.planVersionId,
    status: params.status || 'ACTIVE',
    startsAt: params.startsAt,
    endsAt: params.endsAt,
    acceptedAt: params.acceptedAt || timestamp,
    createdAt: timestamp
  };
}

/**
 * Derives default provider entitlements from an agreement's plan version snapshot.
 */
export function deriveEntitlementsFromPlanVersion(params: {
  agreement: CommercialAgreement;
  planVersion: CommercialPlanVersion;
  now?: string;
}): ProviderEntitlement[] {
  const { agreement, planVersion } = params;
  const timestamp = params.now || new Date().toISOString();
  const snapshot = planVersion.termsSnapshot;

  const entitlements: ProviderEntitlement[] = [];

  const add = (type: EntitlementType, limit?: number, scope?: Record<string, unknown>) => {
    entitlements.push({
      id: `ent_${agreement.id}_${type.toLowerCase()}`,
      providerOrganizationId: agreement.providerOrganizationId,
      commercialAgreementId: agreement.id,
      entitlementType: type,
      limit,
      scope,
      effectiveFrom: agreement.startsAt,
      effectiveUntil: agreement.endsAt,
      createdAt: timestamp
    });
  };

  if (snapshot.includedProducerSeats !== undefined) {
    add('PROVIDER_SEATS', snapshot.includedProducerSeats);
  }
  if (snapshot.includedJurisdictions !== undefined) {
    add('JURISDICTION_CAPACITY', snapshot.includedJurisdictions);
  }
  if (snapshot.includedVpoCapacity !== undefined) {
    add('VPO_VIEW_CAPACITY', snapshot.includedVpoCapacity);
  }
  if (snapshot.includedEngagementCapacity !== undefined) {
    add('VPO_ENGAGEMENT_CAPACITY', snapshot.includedEngagementCapacity);
  }

  return entitlements;
}

/**
 * Checks whether an entitlement allows additional capacity.
 */
export function checkEntitlementCapacity(params: {
  entitlements: ProviderEntitlement[];
  entitlementType: EntitlementType;
  currentUsage: number;
}): { allowed: boolean; limit?: number; current: number; reason?: string } {
  const { entitlements, entitlementType, currentUsage } = params;
  const entitlement = entitlements.find(e => e.entitlementType === entitlementType);

  if (!entitlement) {
    return { allowed: true, current: currentUsage };
  }

  if (entitlement.limit === undefined || entitlement.limit === null) {
    return { allowed: true, limit: undefined, current: currentUsage };
  }

  if (currentUsage >= entitlement.limit) {
    return {
      allowed: false,
      limit: entitlement.limit,
      current: currentUsage,
      reason: `Commercial capacity reached for ${entitlementType}: ${currentUsage}/${entitlement.limit}`
    };
  }

  return { allowed: true, limit: entitlement.limit, current: currentUsage };
}

/**
 * Builds an immutable CommercialEvent with verifiable SHA-256 hash.
 */
export function buildCommercialEvent(params: {
  providerOrganizationId: string;
  eventType: CommercialEventType;
  sourceEntityType: string;
  sourceEntityId: string;
  challengeId?: string;
  competitionId?: string;
  commercialAgreementId?: string;
  commercialPlanVersionId?: string;
  metadata?: Record<string, unknown>;
  idempotencyKey?: string;
  occurredAt?: string;
}): CommercialEvent {
  const occurredAt = params.occurredAt || new Date().toISOString();
  const idempotencyKey = params.idempotencyKey || `${params.eventType}:${params.sourceEntityType}:${params.sourceEntityId}`;

  const payloadToHash = JSON.stringify({
    org: params.providerOrganizationId,
    type: params.eventType,
    srcType: params.sourceEntityType,
    srcId: params.sourceEntityId,
    key: idempotencyKey,
    occurredAt
  });

  const eventHash = crypto.createHash('sha256').update(payloadToHash).digest('hex');

  return {
    id: `cev_${Date.now()}_${Math.floor(1000 + Math.random() * 9000)}`,
    providerOrganizationId: params.providerOrganizationId,
    eventType: params.eventType,
    sourceEntityType: params.sourceEntityType,
    sourceEntityId: params.sourceEntityId,
    challengeId: params.challengeId,
    competitionId: params.competitionId,
    commercialAgreementId: params.commercialAgreementId,
    commercialPlanVersionId: params.commercialPlanVersionId,
    occurredAt,
    metadata: params.metadata,
    idempotencyKey,
    eventHash
  };
}

/**
 * Pure deterministic rating function.
 * Evaluates whether a CommercialEvent generates billable obligation under an agreement.
 */
export function rateCommercialEvent(params: {
  event: CommercialEvent;
  agreement: CommercialAgreement;
  planVersion: CommercialPlanVersion;
  priorUsageCount?: number;
}): RatingDecision {
  const { event, planVersion, priorUsageCount = 0 } = params;
  const snapshot = planVersion.termsSnapshot;

  switch (event.eventType) {
    case 'AUTHORIZED_CONNECTION': {
      const included = snapshot.includedAuthorizedConnections ?? 0;
      const unitPrice = snapshot.authorizedConnectionUnitPriceCents ?? 0;

      if (priorUsageCount < included) {
        return {
          billable: false,
          chargeCode: 'AUTHORIZED_CONNECTION_INCLUDED',
          quantity: 1,
          unitPriceCents: 0,
          amountCents: 0,
          reason: `Included in plan capacity (${priorUsageCount + 1}/${included})`
        };
      }

      if (unitPrice > 0) {
        return {
          billable: true,
          chargeCode: 'AUTHORIZED_CONNECTION_UNIT',
          quantity: 1,
          unitPriceCents: unitPrice,
          amountCents: unitPrice,
          reason: `Billed as Authorized Connection overage above included threshold of ${included}`
        };
      }

      return {
        billable: false,
        chargeCode: 'AUTHORIZED_CONNECTION_NO_FEE',
        reason: 'Authorized Connections are zero-rated under this agreement'
      };
    }

    case 'BOUND_ACQUISITION': {
      const boundPrice = snapshot.boundAcquisitionUnitPriceCents ?? 0;
      if (boundPrice > 0) {
        return {
          billable: true,
          chargeCode: 'BOUND_ACQUISITION_UNIT',
          quantity: 1,
          unitPriceCents: boundPrice,
          amountCents: boundPrice,
          reason: `Billed upon successful Bound Acquisition under commercial agreement`
        };
      }
      return {
        billable: false,
        chargeCode: 'BOUND_ACQUISITION_UNBILLED',
        reason: 'Bound acquisitions are non-billable under subscription-only plan'
      };
    }

    default:
      return {
        billable: false,
        chargeCode: `${event.eventType}_TELEMETRY_ONLY`,
        reason: 'Event recorded for value instrumentation only'
      };
  }
}

/**
 * Calculates factual conversion summary from raw event counts.
 */
export function calculateValueSummary(params: {
  providerOrganizationId: string;
  from: string;
  to: string;
  counts: Record<string, number>;
}): CommercialValueSummary {
  const { providerOrganizationId, from, to, counts } = params;

  const vposAvailable = counts['VPO_AVAILABLE'] || 0;
  const vposViewed = counts['VPO_VIEWED'] || 0;
  const vposEngaged = counts['VPO_ENGAGED'] || 0;
  const propositionsSubmitted = counts['PROPOSITION_SUBMITTED'] || 0;
  const consumerSelections = counts['CONSUMER_SELECTED'] || 0;
  const authorizedConnections = counts['AUTHORIZED_CONNECTION'] || 0;
  const boundAcquisitions = counts['BOUND_ACQUISITION'] || 0;
  const verifiedBoundOutcomes = counts['VERIFIED_BOUND_OUTCOME'] || 0;

  return {
    providerOrganizationId,
    period: { from, to },
    vposAvailable,
    vposViewed,
    vposEngaged,
    propositionsSubmitted,
    consumerSelections,
    authorizedConnections,
    boundAcquisitions,
    verifiedBoundOutcomes,
    conversionRatios: {
      engagementRate: vposAvailable > 0 ? Math.round((vposEngaged / vposAvailable) * 1000) / 1000 : 0,
      selectionRate: vposEngaged > 0 ? Math.round((consumerSelections / vposEngaged) * 1000) / 1000 : 0,
      authorizationRate: consumerSelections > 0 ? Math.round((authorizedConnections / consumerSelections) * 1000) / 1000 : 0,
      bindRate: authorizedConnections > 0 ? Math.round((boundAcquisitions / authorizedConnections) * 1000) / 1000 : 0,
      verificationRate: boundAcquisitions > 0 ? Math.round((verifiedBoundOutcomes / boundAcquisitions) * 1000) / 1000 : 0
    }
  };
}
